/**
 * Created by gleicher on 11/29/15.
 */


/***
 * Example image processing functions for the CS559 Image Processing Assignment
 *
 * This file sets up a list (called "processButtons") that is used in the file
 * image.js
 *
 * Define the image processing operations as functions on the list called "processButtons"
 *
 * processButtons should be a list of functions - preferably functions with names
 * (since the function names will be used to make the buttons)
 *
 * Each function takes a single argument - an "ImageData" object and returns an ImageData object
 * for information on ImageData see: https://developer.mozilla.org/en-US/docs/Web/API/ImageData
 *
 * The processing function can change things in place, or can create a new ImageData object to return
 *
 *
 * Here we create a few example functions and put them onto the processButtons list
 * so that they will be turned into buttons
 */

/**
 * we declare the array - we use the || [] to make the list empty if it hasn't
 * already been defined
 *
  * @type {Array}
 */
var processButtons = processButtons || [];

/**
 * a first function - dim - works in place to dim the image
 */
processButtons.push(
    function dim(imageData) {
        var data = imageData.data;
        // this loops over pixels
        for (var i = 0; i < data.length; i += 4) {
            data[i]     = data[i]/2;         // red
            data[i + 1] = data[i + 1]/2; // green
            data[i + 2] = data[i + 2]/2; // blue
        }
        return imageData;
    }
);

// push another function - since it has no name, it's button will have no name
processButtons.push(
    function(imageData) {
        var data = imageData.data;
        // this loops over pixels
        for (var i = 0; i < data.length; i += 4) {
            data[i+2] = 0;
        }
        return imageData;
    }
);

// push another function - this one creates a new image data
// it would probably be better to make one that is the same size
// as the source
processButtons.push(
    function redSquare(imageData) {
        var newData = new ImageData(50,50);
        var data = newData.data;
        // this loops over pixels
        for (var i = 0; i < data.length; i += 4) {
            data[i]   = 255;
            data[i+1] = 128;
            data[i+2] = 128;
            data[i+3] = 255;
        }
        return newData;
    }
);
